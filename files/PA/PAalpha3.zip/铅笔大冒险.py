import pygame
import sys
class hitBox:
  #碰撞箱
  def __init__(self,x,y,w,h):
    self.x = x
    self.y = y
    self.w = w
    self.h = h

  def move(self,x,y):
  #移动碰撞箱
    self.x += x
    self.y += y

  def bump(self,x,y):
  #碰撞箱是否碰到一个点
    if abs(x - self.x) < self.w/2:
      if abs(y - self.y) < self.h/2:
        return True
      else:
        return False
    else:
      return False

#————分割线————

class enti:
  #这个类为实体，用于存放一个敌怪/子弹/特效/ui等的数据
  def __init__(self,x,y):
    self.x = 0
    self.y = 0
    self.update(x,y,hitBox(0,0,0,0))
    self.entinit()

  def remove(self):
  #移除此实体
    popQueue.add(i)

  def update(self,x,y,HB):
  #更新此实体
    self.x = x
    self.y = y
    self.HB = HB
    self.cos = 0
    self.dp = True# 显示？
    self.flip = False# 左右翻转？

  def move(self,x=0,y=0):
  #移动x和y坐标，如果不移动可以输入0，同时会移动碰撞箱
    self.x += x
    self.y += y
    self.HB.move(x,y)

  def bump(self,x,y):
  #碰撞检测
    return self.HB.bump(x,y)

  def draw(self):
    drawimg(str(type(self))[17:-2],self.cos,self.x,self.y * -1,self.flip)

  def ccos(self,begin,to):
  #使造型循环
    self.cos = cint(self.cos,begin,to)

  def entinit(self):
    pass

class beg(enti):
  def do(self):
    self.cos += 1
    if self.cos == 60:
      self.remove()
    elif self.cos == 55:
      global bg_
      bg_ = 1

class button0(enti):
  def do(self):
    if bg_ == 1:
      self.dp = True
      if self.on:
        if self.cos == 0:
          if key(pygame.K_s):
            self.cos = 1
          elif key(32) or key(13):
            frame("ingame")
            self.on = False
        else:
          if key(pygame.K_w):
            self.cos = 0
          elif key(32) or key(13):
            frame("ingame")
            self.on = False

  def entinit(self):
    self.dp = False
    self.on = True

class switch(enti):
  def do(self):
    if pause:
      return None
    else:
      self.cos += 1
      if self.cos == 61:
        if self.switchTo == "ingame":
          clearAll()
          global player
          global playerDP
          global bg_
          bg_ = 2
          player = pencil(0,-40)
          playerDP = True
          ui.insert(-1,heart(0,0))

      elif self.cos == 64:
          self.remove()

class heart(enti):
  def do(self):
    pass

  def entinit(self):
    self.cos = 12

class pencil(enti):
  def do(self):
    #玩家
    if self.cos in range(15,24):
      self.move(0,round(self.ySpeed * 0.7))
      print(self.ySpeed)
      self.ySpeed -= 1
      if self.y == -40:
        self.cos = 14
      elif self.ySpeed in range(-4,4):
        self.cos += 1
      #跳跃过程
    elif key(119):
      self.cos = 15
      self.ySpeed = 10
    #跳跃操作
    if keyHold(97) and self.x >= -90:
      log(self.x)
      self.flip = True
      if self.cos not in range(15,24):
        self.ccos(0,13)
      self.move(-3)
    elif keyHold(100) and self.x <= 90 and not keyHold(97):
      log(self.x)
      self.flip = False
      if self.cos not in range(15,24):
        self.ccos(0,13)
      self.move(3)
    #移动
    elif self.cos not in range(15,224):
        self.cos = 14

  def entinit(self):
    self.HB = hitBox(0,-40,8,26)
#——分割线——

def cint(now,begin,to):
#使一个int循环，用于循环动画等
  if now >= to:
    return begin
  else:
    return now + 1

def Limg(src,num):
  #读取图片
  list = []
  for i in range(0,num + 1):
    j = str(src) + str(i) + ".png"
    list.append(pygame.transform.scale(pygame.image.load(j),(192 * _scaling,144 * _scaling)))
  print(src + " has loaded")
  return list

def drawimg(typ,cos,coorX,coorY,flip=False):
  #绘制图片，coor为192*144情况下的坐标
  if flip:
    screen.blit(pygame.transform.flip(imgs[str(typ)][int(cos)],True,False),(coorX * _scaling,coorY * _scaling))
  else:
    screen.blit(imgs[str(typ)][int(cos)],(coorX * _scaling,coorY * _scaling))

def key(keyname):
  #获取一个按键是否被*按下*
  return keyname in keyPress

def keyHold(keyname):
  #检测一个按键是否被*按住*
  return bool(holdingKey[keyname])

def addEnt(obj,typ):
  #向列表中加入新实体
  if typ == "ent":
    ent.append(obj)
    return ent[-1]
  elif typ == "eff":
    eff.append(obj)
    return eff[-1]
  if typ == "ui":
    ui.append(obj)
    return ui[-1]

def frame(frameName):
  #框架函数，用于一键更新游戏状态
  pause = True
  addEnt(switch(0,0),"ui").switchTo = frameName

def clearAll():
  #快捷清除三个列表中除转场外的所有实体
  ent.clear()
  eff.clear()
  for _i in range(len(ui)):
    if str(type(ui[_i])) != "<class '__main__.switch'>":
      popQueue.add(_i)
  clearList(ui)

def clearList(li):
  for i in popQueue:
    li.pop(i)
  popQueue.clear()

def log(s):
  #发送一条日志，如果允许使用log
  if logDisplay:
    print(s)
#——分割线——

#变量区：
fpslock = pygame.time.Clock()
bg_ = 0
#背景编号
_scaling = 5
#窗口缩放比例
ent = []
#敌怪和子弹
eff = []
#爆炸等特效
ui = [button0(0,0),beg(0,0)]
#各项ui
pause = False
#是否暂停
player = None
#玩家本体
playerDP = False
#玩家是否显示、运行
imgs = {
  "bg":Limg("bg",3),
  "button0":Limg("button0_",1),
  "beg":Limg("beg_",60),
  "boss1":Limg("boss1_",40),
  "pencil":Limg("pencil_",23),
  "switch":Limg("switch_",64),
  "heart":Limg("heart",16)
  }
#保存所有贴图
keyPress = {"这个集合用于保存每一帧时触发KEYDOWN事件的键盘"}
i = 0
#计次变量
logDisplay = False
#是否显示日志
popQueue = {0}
popQueue.clear()
#移除实体的伪·队列
#——分割线——
#pygame区
pygame.init()
screen = pygame.display.set_mode(size=(192 * _scaling,144 * _scaling))
while True:
  fpslock.tick(30)
  keyPress.clear()
  holdingKey = pygame.key.get_pressed()
  event = pygame.event.get()
  drawimg("bg",bg_,0,0)
  for i in event:
    #遍历事件
    if i.type == pygame.KEYDOWN:
      keyPress.add(i.key)
    elif i.type == pygame.QUIT:
      pygame.quit()
      sys.exit()

  i = 0
  for i in range(len(ent)):
    ent[i].do()
    if ent[i].dp:
      ent[i].draw()
  #可以看出：排在列表后边的实体总会显示在较上层

  clearList(ent)

  i = 0
  for i in range(len(eff)):
    eff[i].do()
    if eff[i].dp:
      eff[i].draw()

  clearList(eff)

  if playerDP:
    player.do()
    if playerDP and player.dp:
      player.draw()

  i = 0
  for i in range(len(ui)):
    ui[i].do()
    if ui[i].dp:
      ui[i].draw()

  clearList(ui)

  if key(99):
    _a = float(input())
    _b = int(input())
    

  pygame.display.update()
"""
可以看出：
* ui总是在玩家上层显示
* 玩家总是能盖过特效
* 特效总是在实体上层显示
* 最后一层是背景
"""
