#这个工程是我的新作《铅笔大冒险》
import pygame
import sys
class hitBox:
  #碰撞箱
  def __init__(self,x,y,w,h):
    self.x = x
    self.y = y
    self.w = w
    self.h = h

  def move(self,x,y):
  #移动碰撞箱
    self.x += x
    self.y += y

  def bump(self,x,y):
  #碰撞箱是否碰到一个点
    if abs(x - self.x) < self.w/2:
      if abs(y - self.y) < self.h/2:
        return True
      else:
        return False
    else:
      return False

#————分割线————

class enti:
  #这个类为实体，用于存放一个敌怪/子弹/特效/ui等的数据
  def __init__(self,typ,x,y,HB=hitBox(0,0,0,0)):
    self.x = 0
    self.y = 0
    self.update(typ,x,y,HB)

  def remove(self):
  #移除此实体
    self.typ = "empty"

  def update(self,typ,x,y,HB):
  #更新此实体，用于原地变成另一实体
    self.typ = typ
    self.x = x
    self.y = y
    self.HB = HB
    self.cos = 0
    self.dp = True
    self.isNewEnt = True
    self.flip = False

  def move(self,x=0,y=0):
  #移动x和y坐标，如果不移动可以输入0，同时会移动碰撞箱
    self.x += x
    self.y += y
    self.HB.move(x,y)

  def bump(self,x,y):
  #碰撞检测
    return self.HB.bump(x,y)

  def draw(self):
    drawimg(self.typ,self.cos,self.x,self.y * -1,self.flip)

  def ccos(self,begin,to):
  #使造型循环
    self.cos = cint(self.cos,begin,to)

  def do(self,typ):
  #执行一帧的刷新
    if typ == "empty":
      return None

    elif pause and not typ in unpauseEnts:
      return None
      
    elif typ == "beg":
      self.cos += 1
      if self.cos == 60:
        self.remove()
      elif self.cos == 55:
        global bg_
        bg_ = 1
        
    elif typ == "button0":
      if self.isNewEnt:
        self.isNewEnt = False
        self.dp = False
      if bg_ == 1:
        self.dp = True
        if self.cos == 0:
          if key(pygame.K_s):
            self.cos = 1
          elif key(32):
            frame("ingame")
        else:
          if key(pygame.K_w):
            self.cos = 0
          elif key(32):
            frame("ingame")
            
    elif typ == "switch":
      if self.isNewEnt:
        self.isNewEnt = False
      else:
        self.cos += 1
        if self.cos == 11:
          if self.switchTo == "ingame":
            clearAll()
            global player
            global playerDP
            bg_ = 2
            player = enti("pencil",0,-40,hitBox(0,-40,8,26))
            playerDP = True

        elif self.cos == 15:
          self.remove()

    elif typ == "pencil":
      if keyHold(97) and self.x >= -90:
        log(self.x)
        self.flip = True
        self.ccos(0,13)
        self.move(-4)
      elif keyHold(100) and self.x <= 90 and not keyHold(97):
        log(self.x)
        self.flip = False
        self.ccos(0,13)
        self.move(4)
      else:
        self.cos = 14

#——分割线——

def cint(now,begin,to):
#使一个int循环，用于循环动画等
  if now >= to:
    return begin
  else:
    return now + 1

def searchEmp(l):
#用于在数据列表中检测第一个空实体，便于加入新实体
#如果不存在合适项则返回长度便于添加新项
  for i_ in range(len(l)):
    if l[i_].typ == "empty":
      return i
  else:
    return i

def Limg(src,num):
  #读取图片
  list = []
  for i in range(0,num + 1):
    j = str(src) + str(i) + ".png"
    list.append(pygame.transform.scale(pygame.image.load(j),(192 * _scaling,144 * _scaling)))
  print(src + " has loaded")
  return list

def drawimg(typ,cos,coorX,coorY,flip=False):
  #绘制图片，coor为192*144情况下的坐标
  if flip:
    screen.blit(pygame.transform.flip(imgs[str(typ)][int(cos)],True,False),(coorX * _scaling,coorY * _scaling))
  else:
    screen.blit(imgs[str(typ)][int(cos)],(coorX * _scaling,coorY * _scaling))

def key(keyname):
  #获取一个按键是否被*按下*
  return keyname in keyPress

def keyHold(keyname):
  #检测一个按键是否被*按住*
  return bool(holdingKey[keyname])

def addEnt(obj,typ):
  #向列表中加入新实体
  if typ == "ent":
    global ent
    i = searchEmp(ent)
    ent[i] =obj
  elif typ == "eff":
    global eff
    i = searchEmp(eff)
    eff[i] =obj
  if typ == "ui":
    global ui
    i = searchEmp(ui)
    ui[i] =obj
  return i

def frame(frameName):
  #框架函数，用于一键更新游戏状态
  pause = True
  ui[addEnt(enti("switch",0,0),"ui")].switchTo = frameName

def clearAll():
  #快捷清除三个列表中除转场外的所有实体
  ent.clear()
  eff.clear()
  for _i in range(len(ui)):
    if ui[_i].typ != "switch":
      ui.pop(_i)

def log(s):
  #发送一条日志，如果允许使用log
  if logDisplay:
    print(s)
#——分割线——

#变量区：
fpslock = pygame.time.Clock()
bg_ = 0
#背景编号
_scaling = 5
#窗口缩放比例
ent = []
#敌怪和子弹
eff = []
#爆炸等特效
ui = [enti("button0",0,0),enti("beg",0,0)]
#各项ui
pause = False
#是否暂停
unpauseEnts={"switch"}
#字面意思，可以无视暂停的实体（如某些ui）
player = None
playerDP = False
#玩家数据
imgs = {
  "bg":Limg("bg",3),
  "button0":Limg("button0_",1),
  "beg":Limg("beg_",60),
  "boss1":Limg("boss1_",40),
  "pencil":Limg("pencil_",14),
  "switch":Limg("switch_",14)
  }
#贴图
keyPress = {"这个集合用于保存每一帧时触发KEYDOWN事件的键盘"}
i = 0
logDisplay = False
#是否显示日志
#——分割线——
#pygame区
pygame.init()
screen = pygame.display.set_mode(size=(192 * _scaling,144 * _scaling))
while True:
  fpslock.tick(20)
  keyPress.clear()
  holdingKey = pygame.key.get_pressed()
  event = pygame.event.get()
  drawimg("bg",bg_,0,0)
  for i in event:
    if i.type == pygame.KEYDOWN:
      keyPress.add(i.key)
    elif i.type == pygame.QUIT:
      pygame.quit()
      sys.exit()

  i = 0
  while i < len(ent):
    if ent[i].typ != "empty":
      ent[i].do(ent[i].typ)
      if ent[i].typ != "empty" and ent[i].dp:
        ent[i].draw()
    i += 1

  i = 0
  while i < len(eff):
    if eff[i].typ != "empty":
      eff[i].do(eff[i].typ)
      if eff[i].typ != "empty" and eff[i].dp:
        eff[i].draw()
    i += 1
    
  if playerDP:
    player.do("pencil")
    if playerDP and player.dp:
      player.draw()

  i = 0
  while i < len(ui):
    if ui[i].typ != "empty":
      ui[i].do(ui[i].typ)
      if ui[i].typ != "empty" and ui[i].dp:
        ui[i].draw()
    i += 1

  if key(99):
    __com__ = input("请输入指令:")
    if __com__[0:9] == "showList ":
      if __com__[9:12] == "ent":
        print(ent)
      elif __com__[9:12] == "eff":
        print(eff)
      elif __com__[9:11] == "ui":
        print(ui)
      elif __com__[9:12] == "all":
        print(enti)
        print(eff)
        print(ui)
    elif __com__[0:5] == "logs ":
      if __com__[5:7] == "on":
        logDisplay = True
      elif __com__[5:8] == "off":
        logDisplay = False
  
  pygame.display.update()
